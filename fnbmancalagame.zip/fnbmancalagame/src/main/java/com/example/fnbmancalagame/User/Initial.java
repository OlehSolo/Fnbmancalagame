package com.example.fnbmancalagame.User;

import lombok.Value;

@Value
public class Initial {
    private Integer index;
    private Boolean isLeftTurn;
}
