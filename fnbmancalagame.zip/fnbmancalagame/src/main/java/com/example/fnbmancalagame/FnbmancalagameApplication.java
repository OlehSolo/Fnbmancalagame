package com.example.fnbmancalagame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FnbmancalagameApplication {

    public static void main(String[] args) {
        SpringApplication.run(FnbmancalagameApplication.class, args);
    }

}
