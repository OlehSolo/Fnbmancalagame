package com.example.fnbmancalagame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FnbmancalagameApplicationTests {

    @Test
    void contextLoads() {
    }

}
